# PHddos

**A powerfull ddos tool designed to only works on Termux application.**

![ddos proof](https://github.com/PHhackers/PHddos/blob/main/Screenshot_2022-04-15-16-54-02-13_948cd9899890cbd5c2798760b2b95377.jpg)

**HOW TO INSTALL AND USE**

git clone https://github.com/PHhackers/PHddos/  

cd PHddos   

python3 PHddos.py   

press y or accept the permission   

Enter Url and Time.   

Launch attack.   

![ddos proof](https://github.com/PHhackers/PHddos/blob/main/Screenshot_2022-04-15-17-09-07-61_99c04817c0de5652397fc8b56c3b3817.jpg)


**ENJOY**
